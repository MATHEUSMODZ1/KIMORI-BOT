#!/bin/sh

WHITE='\033[1;37m'
RESET='\033[0m'

circle_spinner() {
    delay=0.20
    count=0
    while [ "$count" -lt 2 ]; do
        for frame in "   ●     " "  ●      " " ●       " "●        " " ●       " "  ●      " "   ●     " "    ●    " "     ●   " "      ●  " "       ● " "        ●" "       ● " "      ●  " "     ●   " "    ●    "
        do
            printf "\r${WHITE}Kimori System         $frame${RESET}"
            sleep "$delay"
        done
        count=$((count + 1))
    done
    printf "\n"
}

while true
do
    circle_spinner
    printf "${WHITE}Iniciando Kimori System...\n${RESET}"
    node iniciar.js --code
    printf "${WHITE}︎\nReiniciando Kimori System...\n${RESET}"
    sleep 1
done