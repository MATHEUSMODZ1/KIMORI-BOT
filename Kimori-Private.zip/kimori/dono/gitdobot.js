const gitdobot = (prefix) => {
return`teks`;
};

exports.gitdobot = gitdobot;
