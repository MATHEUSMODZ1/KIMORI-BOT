case 'menu':
if(isButao) {
await conn.relayMessage(from, {
interactiveMessage: {
header: proto.Message.InteractiveMessage.Header.create({
...(await prepareWAMessageMedia(
{ video: { url: 'https://files.catbox.moe/wvzjdn.mp4', gifPlayback: true } },
{ upload: conn.waUploadToServer }
)),
hasMediaAttachment: true,
title: ``,
}),
body: {
text: ``
},
footer: { text: "『© KIMORI SYSTEM』" },
nativeFlowMessage: {
buttons: [
{
name: "single_select",
buttonParamsJson: JSON.stringify({
title: "🍇𝓜𝓮𝓷𝓾 𝓛𝓲𝓼𝓽🍇",
sections: [
{
title: "🍇MENU PRINCIPAL 🍇",
highlight_label: "",
rows: [
{ title: "𝙼𝚎𝚗𝚞 𝚘𝚗𝚍𝚎 𝚎𝚜𝚝𝚊 𝚚𝚞𝚊𝚜𝚎 𝚝𝚘𝚍𝚘𝚜 𝚘𝚜 𝚌𝚖𝚍𝚜.", 
id: `${prefix}menup`, 
description: "𝑩𝒚: 𝐊𝐢𝐦𝐨𝐫𝐢 𝐃𝐨𝐦𝐢𝐧𝐚 ✿︎" }
]
},

{
title: "🍇MENU DOS DONOS🍇",
highlight_label: "",
rows: [
{ title: "𝙼𝚎𝚗𝚞 𝚍𝚘 𝚍𝚘𝚗𝚘 𝚍𝚊 𝙱𝚘𝚝", 
id: `${prefix}menudono`, 
description: "𝑩𝒚: 𝐊𝐢𝐦𝐨𝐫𝐢 𝐃𝐨𝐦𝐢𝐧𝐚 ✿︎" }
]
},

{
title: "🍇MENU DE ADMS🍇",
highlight_label: "",
rows: [
{ title: "𝙼𝚎𝚗𝚞 𝚍𝚎 𝙰𝚍𝚖 𝚍𝚘𝚜 𝚐𝚛𝚞𝚙𝚘𝚜", 
id: `${prefix}menuadm`, 
description: "𝑩𝒚: 𝐊𝐢𝐦𝐨𝐫𝐢 𝐃𝐨𝐦𝐢𝐧𝐚 ✿︎" }
]
},

{
title: "🍇MENU PREMIUM🍇",
highlight_label: "",
rows: [
{ title: "𝙼𝚎𝚗𝚞 𝚍𝚎 𝚞𝚜𝚞𝚊𝚛𝚒𝚘𝚜 𝚙𝚛𝚎𝚖𝚒𝚞𝚗𝚜", 
id: `${prefix}menupremium`, 
description: "𝑩𝒚: 𝐊𝐢𝐦𝐨𝐫𝐢 𝐃𝐨𝐦𝐢𝐧𝐚 ✿︎" }
]
},

{
title: "🍇MENU DE EFEITOS🍇",
highlight_label: "",
rows: [
{ title: "𝙼𝚎𝚗𝚞 𝚍𝚎 𝚎𝚏𝚎𝚒𝚝𝚘𝚍 𝚍𝚊 𝙱𝚘𝚝", 
id: `${prefix}efeitosimg`, 
description: "𝑩𝒚: 𝐊𝐢𝐦𝐨𝐫𝐢 𝐃𝐨𝐦𝐢𝐧𝐚 ✿︎" }
]
},

{
title: "🍇MENU DE LOGOS🍇",
highlight_label: "",
rows: [
{ title: "𝙼𝚎𝚗𝚞 𝚍𝚎 𝙻𝚘𝚐𝚘𝚜 𝚍𝚊 𝙱𝚘𝚝", 
id: `${prefix}logos`, 
description: "𝑩𝒚: 𝐊𝐢𝐦𝐨𝐫𝐢 𝐃𝐨𝐦𝐢𝐧𝐚 ✿︎" }
]
},

{
title: "🍇MENU DE BRINCADEIRAS🍇",
highlight_label: "",
rows: [
{ title: "𝙼𝚎𝚗𝚞 𝚍𝚎 𝚋𝚛𝚒𝚗𝚌𝚊𝚍𝚎𝚒𝚛𝚊𝚜 𝚍𝚊 𝙱𝚘𝚝", 
id: `${prefix}brincadeiras`, 
description: "𝑩𝒚: 𝐊𝐢𝐦𝐨𝐫𝐢 𝐃𝐨𝐦𝐢𝐧𝐚 ✿︎" }
]
},

{
title: "🍇INFO DA BOT🍇",
highlight_label: "",
rows: [
{ title: "𝙸𝚗𝚏𝚘𝚛𝚖𝚊𝚌̧𝚘̃𝚎𝚜 𝚍𝚊 𝙱𝚘𝚝", 
id: `${prefix}infobot`, 
description: "𝑩𝒚: 𝐊𝐢𝐦𝐨𝐫𝐢 𝐃𝐨𝐦𝐢𝐧𝐚 ✿︎" }
]
},

{
title: "🍇ATIVAÇÕES🍇",
highlight_label: "",
rows: [
{ title: "𝙰𝚝𝚒𝚟𝚊𝚌̧𝚘̃𝚎𝚜 𝚍𝚘𝚜 𝙶𝚛𝚞𝚙𝚘𝚜", 
id: `${prefix}ativacoes`, 
description: "𝑩𝒚: 𝐊𝐢𝐦𝐨𝐫𝐢 𝐃𝐨𝐦𝐢𝐧𝐚 ✿︎" }
]
},

{
title: "🍇VELOCIDADE DA BOT🍇",
highlight_label: "",
rows: [
{ title: "𝚅𝚎𝚕𝚘𝚌𝚒𝚍𝚊𝚍𝚎 𝙳𝚊 𝙱𝚘𝚝", 
id: `${prefix}ping`, 
description: "𝑩𝒚: 𝐊𝐢𝐦𝐨𝐫𝐢 𝐃𝐨𝐦𝐢𝐧𝐚 ✿︎" }
]
}

]
})
},
{
name: "cta_url",
buttonParamsJson: JSON.stringify({
display_text: "🍇🛒KIMORI-SHOP🛒🍇",
url: "https://wa.me/5538991164328?text=Eu_Quero_Comprar_a_Kimori_ou_Alugar"
})
}
],
messageParamsJson: ""
}
}
}, {});
} else {
  conn.sendMessage(from, {
    video: { url: 'https://files.catbox.moe/wvzjdn.mp4' },
    caption: menu(prefix, NomeDoBot, sender),
    gifPlayback: true,
    mentions: [sender]
  }, { quoted: selo });
  }
break