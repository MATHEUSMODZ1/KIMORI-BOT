const emojiku = "ᰔᩚ⃝🌹›";
const botv = "1.2.7";

const menu = (prefix, NomeDoBot, sender) => {
return `​✧━━━━━━━━🌟━━━━━━━━✧
*🌹💫 𝓤𝓼𝓮𝓻:* @${sender.split("@")[0]}
*🌹🚀 𝓥𝓮𝓻𝓼𝓪𝓸:* ${botv}  
*🌹🤖 𝓑𝓸𝓽:* ${NomeDoBot}  
✧━━━━━━━━🌟━━━━━━━━✧

  🌹ᩚ⃝⃝ ｡˚𝐌𝐄𝐍𝐔 𝐃𝐎𝐒 𝐌𝐄𝐍𝐔𝐒˚｡🌹ᩚ⃝⃝

╭─〔🌹𝐃𝐈𝐕𝐄𝐑𝐒𝐎𝐒 𝐌𝐄𝐍𝐔𝐒🌹〕─╮
┊${emojiku}${prefix}Menudono
┊${emojiku}${prefix}Menuadm
┊${emojiku}${prefix}Menupremium
┊${emojiku}${prefix}menueffect
┊${emojiku}${prefix}menulogos
┊${emojiku}${prefix}menuzoas
╰─〔🌹𝐅𝐈𝐍𝐀𝐋 𝐃𝐎𝐒 𝐌𝐄𝐍𝐔𝐒🌹〕─╯

╭─〔🌹𝐂𝐌𝐃 𝐃𝐄 𝐌𝐄𝐌𝐁𝐑𝐎🌹〕─╮
┊${emojiku}${prefix}Idiomas (𝙸𝚍𝚒𝚘𝚖𝚜)
┊${emojiku}${prefix}Bug (𝚀𝚞𝚎𝚜𝚝𝚒𝚘𝚗𝚎) 
┊${emojiku}${prefix}Sugestao (𝙳𝚒𝚌𝚊𝚜) 
┊${emojiku}${prefix}Avalie (0 𝚊 10) 
┊${emojiku}${prefix}Play (𝚗𝚊𝚖𝚎 𝚖𝚞𝚜𝚒𝚌)
┊${emojiku}${prefix}moedas (𝙱𝚁 𝙴𝚄𝙰)
┊${emojiku}${prefix}Sticker (𝙼𝙴𝙽𝙲 𝙵𝙸𝙶𝚄)
╰─〔𝐁𝐘: 𝐊𝐈𝐌𝐎𝐑𝐈 𝐃𝐎𝐌𝐈𝐍𝐀🌹〕─╯`;
};

exports.menu = menu;
const adms = (prefix, sender) => { 
 
	return `​✧━━━━━━━━🌟━━━━━━━━✧
*🌹💫 𝓤𝓼𝓮𝓻:* @${sender.split("@")[0]}
*🌹🚀 𝓥𝓮𝓻𝓼𝓪𝓸:* ${botv}  
✧━━━━━━━━🌟━━━━━━━━✧
╭─〔🌹𝐌𝐄𝐍𝐔 𝐃𝐄 𝐀𝐃𝐌𝐒🌹〕─╮
┊${emojiku}${prefix}ativacoes
┊${emojiku}${prefix}so_adm
┊${emojiku}${prefix}listanegra (NUMERO)
┊${emojiku}${prefix}tirardalista (NUMERO)
┊${emojiku}${prefix}listanegraG (NÚMERO)
┊${emojiku}${prefix}tirardalistaG (NÚMERO)
┊${emojiku}${prefix}Kick [@] (pra-remover) 
┊${emojiku}${prefix}Ban (responder-mensagem)
┊${emojiku}${prefix}Promover [@] (Ser-ADM)
┊${emojiku}${prefix}Rebaixar [@] (rebaixar-adm)
┊${emojiku}${prefix}Totag (menciona-algo)
┊${emojiku}${prefix}Grupo f/a
┊${emojiku}${prefix}Status
┊${emojiku}${prefix}Limpar (texto-invisível-gp)
┊${emojiku}${prefix}Atividades (DO-GRUPO)
┊${emojiku}${prefix}Linkgp
┊${emojiku}${prefix}Grupoinfo
┊${emojiku}${prefix}Hidetag (txt) (marcação)
┊${emojiku}${prefix}Marcar (marca tds do gp)
┊${emojiku}${prefix}Marcar2 (Marca-tds-Wa.me/)
┊${emojiku}${prefix}Antipalavra 1 / 0
┊${emojiku}${prefix}Descgp (TXT)
┊${emojiku}${prefix}Nomegp (Nome)
┊${emojiku}${prefix}Criartabela (ESCREVA-ALGO)
┊${emojiku}${prefix}Tabelagp
╰─〔𝐁𝐘: 𝐊𝐈𝐌𝐎𝐑𝐈 𝐃𝐎𝐌𝐈𝐍𝐀🌹〕─╯
`;
};

exports.adms = adms;

const menudono = (prefix, sender) => {

return `✧━━━━━━━━🌟━━━━━━━━✧
*🌹💫 𝓤𝓼𝓮𝓻:* @${sender.split("@")[0]}
*🌹🚀 𝓥𝓮𝓻𝓼𝓪𝓸:* ${botv}  
✧━━━━━━━━🌟━━━━━━━━✧
​╭─〔🌹𝐌𝐄𝐍𝐔 𝐃𝐄 𝐃𝐎𝐍𝐎🌹〕─╮
┊${emojiku}${prefix}ativacoes_dono
┊${emojiku}${prefix}Bangp
┊${emojiku}${prefix}Unbangp
┊${emojiku}${prefix}Fotomenu (MARCAR-IMG) 
┊${emojiku}${prefix}Blockcmd  (cmd)
┊${emojiku}${prefix}Unblockcmd (cmd)
┊${emojiku}${prefix}Legenda_estrangeiro (msg)
┊${emojiku}${prefix}Legendabv (oq qr)
┊${emojiku}${prefix}Legendasaiu (oq qr)
┊${emojiku}${prefix}Legendasaiu2 (oq qr)
┊${emojiku}${prefix}Legendabv2 (oq qr)
┊${emojiku}${prefix}Fundobemvindo (marcar-img)
┊${emojiku}${prefix}Fundosaiu (marcar-img)
┊${emojiku}${prefix}Serpremium
┊${emojiku}${prefix}Listagp
┊${emojiku}${prefix}Antipalavrão 1 / 0
┊${emojiku}${prefix}Antiligar 1 / 0
┊${emojiku}${prefix}Addpalavra (palavrão)
┊${emojiku}${prefix}Delpalavra (palavrão)
┊${emojiku}${prefix}Ativo
┊${emojiku}${prefix}Ausente (fale-oq-faz)
┊${emojiku}${prefix}Delpremium @(marca)
┊${emojiku}${prefix}Addpremium @(marca)
┊${emojiku}${prefix}Clonar [@] (rouba ft de prf)
┊${emojiku}${prefix}Fotobot (img, = foto do BT)
┊${emojiku}${prefix}Descriçãogp (digite-algo)
┊${emojiku}${prefix}Block [@] (bloq de usar cmds) 
┊${emojiku}${prefix}Unblock [@] (desbloquear) 
┊${emojiku}${prefix}Setprefix  (prefixo-novo)
┊${emojiku}${prefix}Bcgp (TM-PRA-PV-MEMBROS)
╰─〔𝐁𝐘: 𝐊𝐈𝐌𝐎𝐑𝐈 𝐃𝐎𝐌𝐈𝐍𝐀🌹〕─╯
`;

};

exports.menudono = menudono;

const menulogos = (prefix, sender) => {
  
  return `​✧━━━━━━━━🌟━━━━━━━━✧
*🌹💫 𝓤𝓼𝓮𝓻:* @${sender.split("@")[0]}
*🌹🚀 𝓥𝓮𝓻𝓼𝓪𝓸:* ${botv}  
✧━━━━━━━━🌟━━━━━━━━✧
╭─〔🌹𝐌𝐄𝐍𝐔 𝐃𝐄 𝐋𝐎𝐆𝐎𝐒🌹〕─╮
┊${emojiku}${prefix}logos1 (txt) 
┊${emojiku}${prefix}Comporn (txt/txt) 
┊${emojiku}${prefix}Glitch (txt/txt)
┊${emojiku}${prefix}Glitch3 (txt/txt)
┊${emojiku}${prefix}Grafity (txt-txt)
┊${emojiku}${prefix}Space (txt/txt)
┊${emojiku}${prefix}Marvel (txt/txt)
┊${emojiku}${prefix}Stone (txt/txt)
┊${emojiku}${prefix}Steel (txt/txt)
╰─〔𝐁𝐘: 𝐊𝐈𝐌𝐎𝐑𝐈 𝐃𝐎𝐌𝐈𝐍𝐀🌹〕─╯
`;
};

exports.menulogos = menulogos;

const alteradores = (prefix, sender) => {

return`✧━━━━━━━━🌟━━━━━━━━✧
*🌹💫 𝓤𝓼𝓮𝓻:* @${sender.split("@")[0]}
*🌹🚀 𝓥𝓮𝓻𝓼𝓪𝓸:* ${botv}  
✧━━━━━━━━🌟━━━━━━━━✧
╭─〔🌹𝐌𝐄𝐍𝐔 𝐀𝐋𝐓𝐄𝐑𝐀𝐃𝐎𝐑🌹〕─╮
┊${emojiku}${prefix}Videolento (marca)
┊${emojiku}${prefix}Videorapido (marca)
┊${emojiku}${prefix}Videocontrario (marca)
┊${emojiku}${prefix}Audiolento (marca)
┊${emojiku}${prefix}Audiorapido (marca)
┊${emojiku}${prefix}Grave (marca)
┊${emojiku}${prefix}Grave2 (marca)
┊${emojiku}${prefix}Esquilo (marca)
┊${emojiku}${prefix}Estourar (marca)
┊${emojiku}${prefix}Bass (marca)
┊${emojiku}${prefix}Bass2 (marca)
┊${emojiku}${prefix}Vozmenino (marca)
┊${emojiku}${prefix}Audioreverse (marca)
╰─〔𝐁𝐘: 𝐊𝐈𝐌𝐎𝐑𝐈 𝐃𝐎𝐌𝐈𝐍𝐀🌹〕─╯
`;
};

exports.alteradores = alteradores;

const menuprem = (prefix, sender) => { 

return `✧━━━━━━━━🌟━━━━━━━━✧
*🌹💫 𝓤𝓼𝓮𝓻:* @${sender.split("@")[0]}
*🌹🚀 𝓥𝓮𝓻𝓼𝓪𝓸:* ${botv}  
✧━━━━━━━━🌟━━━━━━━━✧
╭─〔🌹𝐌𝐄𝐍𝐔 𝐏𝐑𝐄𝐌𝐈𝐔𝐌🌹〕─╮
│✾▹ ADICIONE SEUS COMANDOS PREMIUM / VEJA O ${prefix}infopremium
╰─〔𝐁𝐘: 𝐊𝐈𝐌𝐎𝐑𝐈 𝐃𝐎𝐌𝐈𝐍𝐀🌹〕─╯
`;
};

exports.menuprem = menuprem;

const brincadeiras = (prefix, sender) => {

return `​✧━━━━━━━━🌟━━━━━━━━✧
*🌹💫 𝓤𝓼𝓮𝓻:* @${sender.split("@")[0]}
*🌹🚀 𝓥𝓮𝓻𝓼𝓪𝓸:* ${botv}  
✧━━━━━━━━🌟━━━━━━━━✧
╭─〔🌹𝐌𝐄𝐍𝐔 𝐃𝐄 𝐁𝐑𝐈𝐍𝐊𝐒🌹〕─╮
┊${emojiku}${prefix}Gay (marca (@))
┊${emojiku}${prefix}Feio (marca (@))
┊${emojiku}${prefix}Corno (marca (@))
┊${emojiku}${prefix}Vesgo (marca (@))
┊${emojiku}${prefix}Bebado (marca (@))
┊${emojiku}${prefix}Gostoso (marca (@))
┊${emojiku}${prefix}Gostosa (marca (@))
┊${emojiku}${prefix}Beijo (marca (@))
┊${emojiku}${prefix}Matar (marca (@))
┊${emojiku}${prefix}Tapa (marca (@))
┊${emojiku}${prefix}Chute (marca (@))
┊${emojiku}${prefix}Dogolpe (marca (@))   
┊${emojiku}${prefix}Nazista (marca (@))
┊${emojiku}${prefix}Chance (fale algo) 
┊${emojiku}${prefix}Casal   
┊${emojiku}${prefix}Rankgay     
┊${emojiku}${prefix}Rankgado
┊${emojiku}${prefix}Rankcorno  
┊${emojiku}${prefix}Rankgostoso
┊${emojiku}${prefix}Rankgostosa
┊${emojiku}${prefix}Ranknazista
┊${emojiku}${prefix}Rankotakus
┊${emojiku}${prefix}Rankpau
╰─〔𝐁𝐘: 𝐊𝐈𝐌𝐎𝐑𝐈 𝐃𝐎𝐌𝐈𝐍𝐀🌹〕─╯
`;
};

exports.brincadeiras = brincadeiras;


const efeitos = (prefix, sender) => {

return `✧━━━━━━━━🌟━━━━━━━━✧
*🌹💫 𝓤𝓼𝓮𝓻:* @${sender.split("@")[0]}
*🌹🚀 𝓥𝓮𝓻𝓼𝓪𝓸:* ${botv}  
✧━━━━━━━━🌟━━━━━━━━✧
╭─〔🌹𝐌𝐄𝐍𝐔 𝐃𝐄 𝐄𝐅𝐄𝐈𝐓𝐎𝐒🌹〕─╮
┊${emojiku}${prefix}Legenda (marcar)-(img)
┊${emojiku}${prefix}Procurado (marcar)-(img)
┊${emojiku}${prefix}Hitler (marcar)-(img)
┊${emojiku}${prefix}Preso (marcar)-(img)
┊${emojiku}${prefix}Lixo (marcar)-(img)
┊${emojiku}${prefix}Deletem (marcar)-(img)
┊${emojiku}${prefix}Morto (marcar)-(img) 
┊${emojiku}${prefix}Lgbt (marcar)-(img) 
╰─〔𝐁𝐘: 𝐊𝐈𝐌𝐎𝐑𝐈 𝐃𝐎𝐌𝐈𝐍𝐀🌹〕─╯`;
};

exports.efeitos = efeitos;


const menuinfo = (prefix, sender) => { 

return `✧━━━━━━━━🌟━━━━━━━━✧
*🌹💫 𝓤𝓼𝓮𝓻:* @${sender.split("@")[0]}
*🌹🚀 𝓥𝓮𝓻𝓼𝓪𝓸:* ${botv}  
✧━━━━━━━━🌟━━━━━━━━✧
​╭─✧─✧─✧─✧─✧─✧─✧─✧─╮
│    ᰔᩚ MENU DE INFOS ᰔᩚ
╰─✧─✧─✧─✧─✧─✧─✧─✧─╯
╭┄✧┄✧┄✧┄✧┄✧┄✧┄✧┄✧┄╮
┊${emojiku}${prefix}infoAluguel
┊${emojiku}${prefix}infopremium
┊${emojiku}${prefix}infoforca
┊${emojiku}${prefix}Infoduelo
┊${emojiku}${prefix}Infotransmitir
┊${emojiku}${prefix}InfoMultiPrefixo
┊${emojiku}${prefix}InfoBemvindo
┊${emojiku}${prefix}Infopalavrão
┊${emojiku}${prefix}Infolistanegra
┊${emojiku}${prefix}Infobancarac
┊${emojiku}${prefix}Infovotação
┊${emojiku}${prefix}InfoBanghost
┊${emojiku}${prefix}Infosorteio 
┊${emojiku}${prefix}InfoAnotação
╰┄✧┄✧┄✧┄✧┄✧┄✧┄✧┄✧┄╯
`;
};

exports.menuinfo = menuinfo;

const menudw = (prefix, sender) => { 

return `✧━━━━━━━━🌟━━━━━━━━✧
*🌹💫 𝓤𝓼𝓮𝓻:* @${sender.split("@")[0]}
*🌹🚀 𝓥𝓮𝓻𝓼𝓪𝓸:* ${botv}  
✧━━━━━━━━🌟━━━━━━━━✧
╭┄✧┄✧┄✧┄✧┄✧┄✧┄✧┄✧┄╮
│   PESQUISAS/BAIXAR
╰┄✧┄✧┄✧┄✧┄✧┄✧┄✧┄✧┄╯
╭┄✧┄✧┄✧┄✧┄✧┄✧┄✧┄✧┄╮
┊${emojiku}${prefix}Play (NOME) 
┊${emojiku}${prefix}Playmp4 (NOME)
┊${emojiku}${prefix}playstore ( NOME )
┊${emojiku}${prefix}Ytsearch (NOME)
┊${emojiku}${prefix}Ytmp4 (LINK) 
┊${emojiku}${prefix}Ytmp3 (LINK) 
┊${emojiku}${prefix}Tiktok (LINK) 
┊${emojiku}${prefix}Instagram (LINK) 
┊${emojiku}${prefix}Facebook (LINK) 
┊${emojiku}${prefix}Twitter (LINK) 
┊${emojiku}${prefix}Imgpralink (MARCAR)
┊${emojiku}${prefix}Videopralink (MARCAR-V)
┊${emojiku}${prefix}Amazon (EXEMPLO: Celular A13)
╰┄✧┄✧┄✧┄✧┄✧┄✧┄✧┄✧┄╯
`;
};

exports.menudw = menudw;