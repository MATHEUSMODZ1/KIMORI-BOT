 OI SEUS GAYS KAKAKAKKAKA
 AQUI VAI A INSTALAÇÃO DO BOT 😎
 
#A INSTALAÇÃO SIMPLES E FACIL
 
 ***1 USE sh atualizar.sh***
 
 ***2 Use sh start.sh***
 
 E thanks meus gays kakakakak

____________________________________
 
**O 1 instala todas os as coisas**
 
**O 2 inicia o bot.**



          © Kimori System 2025
          © Version 2.0.1 Update
                  Official             

#By ___Matheus </>___
#By ___Vaso Devs___